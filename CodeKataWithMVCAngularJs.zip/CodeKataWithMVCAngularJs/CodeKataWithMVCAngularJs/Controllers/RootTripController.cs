﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EntityLayer;
using System.IO;

namespace CodeKataWithMVCAngularJs.Controllers
{
    public class RootTripController : Controller
    {
        // GET: RootTrip
        public ActionResult UploadFile()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UploadFile(HttpPostedFileBase file)
        {
            List<Driver> driverList = new List<Driver>();
            List<Trip> tripList = new List<Trip>();

            try
            {
                if (file.ContentLength > 0)
                {
                    string _FileName = Path.GetFileName(file.FileName);
                    string _path = Path.Combine(Server.MapPath("~/UploadedFiles"), _FileName);
                    file.SaveAs(_path);

                    List<string> texts = System.IO.File.ReadLines(_path).ToList();
                    if (texts != null && texts.Count > 0)
                    {
                        foreach (var item in texts)
                        {
                            if (!string.IsNullOrEmpty(item))
                            {
                                if (item.StartsWith("Driver", StringComparison.OrdinalIgnoreCase))
                                {
                                    Driver dv = new Driver();
                                    dv.AddedOn = DateTime.Now;

                                    string[] driver = item.Split(' ');
                                    if (driver.Length == 2)
                                    {
                                        dv.Name = driver[1];
                                        driverList.Add(dv);
                                    }
                                }
                                else if (item.StartsWith("Trip", StringComparison.OrdinalIgnoreCase))
                                {

                                    Trip trip = new Trip();

                                    string[] tripArr = item.Split(' ');

                                    if (tripArr.Length == 5)
                                    {
                                        //trip.DriverDetails = new Driver { Name = tripArr[1] };
                                        trip.DriverName = tripArr[1];
                                        trip.TripStart = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy") + " " + tripArr[2]);
                                        trip.TripEnd = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy") + " " + tripArr[3]);
                                        trip.DistanceTravelled = Convert.ToDouble(tripArr[4]);
                                        trip.TripVelocity = trip.DistanceTravelled / (trip.TripEnd.Subtract(trip.TripStart).TotalMinutes / 60.00);

                                        tripList.Add(trip);
                                    }
                                }
                            }
                        }
                    }

                    if (driverList != null & driverList.Count > 0)
                    {
                        foreach (var drvItem in driverList)
                        {
                            drvItem.TripList = tripList.Where(x => x.DriverName == drvItem.Name).Select(y => y).ToList();
                        }
                        using (BusinessLayer.RootTripBAL obj = new BusinessLayer.RootTripBAL())
                        {
                            driverList = obj.InsertDriverAndTrip(driverList);
                        }
                    }
                }



                ViewBag.Message = "File Uploaded Successfully!!";
                return View(tripList);
            }
            catch(Exception ex)
            {
                ViewBag.Message = "File upload failed!! " + ex.ToString();
                return View(ex.ToString());
            }
        }

        
    }
}
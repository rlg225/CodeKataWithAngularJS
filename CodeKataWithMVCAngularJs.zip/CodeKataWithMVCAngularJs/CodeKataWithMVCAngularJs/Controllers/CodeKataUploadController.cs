﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using EntityLayer;

namespace CodeKataWithMVCAngularJs.Controllers
{
    public class CodeKataUploadController : ApiController
    {
        [Route("api/CodeKataUpload/UploadFiles")]
        [HttpPost]
        public HttpResponseMessage UploadFiles()
        {
            try
            {
                List<Driver> driverList = new List<Driver>();
                List<Trip> tripList = new List<Trip>();
                //Create the Directory.
                string path = HttpContext.Current.Server.MapPath("~/Uploads/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                //Save the Files.
                foreach (string key in HttpContext.Current.Request.Files)
                {
                    HttpPostedFile postedFile = HttpContext.Current.Request.Files[key];
                    postedFile.SaveAs(path + postedFile.FileName);

                    string _path = Path.Combine(path, postedFile.FileName);
                    List<string> texts = System.IO.File.ReadLines(_path).ToList();
                    if (texts != null && texts.Count > 0)
                    {
                        foreach (var item in texts)
                        {
                            if (!string.IsNullOrEmpty(item))
                            {
                                if (item.StartsWith("Driver", StringComparison.OrdinalIgnoreCase))
                                {
                                    Driver dv = new Driver();
                                    dv.AddedOn = DateTime.Now;

                                    string[] driver = item.Split(' ');
                                    if (driver.Length == 2)
                                    {
                                        dv.Name = driver[1];
                                        driverList.Add(dv);
                                    }
                                }
                                else if (item.StartsWith("Trip", StringComparison.OrdinalIgnoreCase))
                                {

                                    Trip trip = new Trip();

                                    string[] tripArr = item.Split(' ');

                                    if (tripArr.Length == 5)
                                    {
                                        //trip.DriverDetails = new Driver { Name = tripArr[1] };
                                        trip.DriverName = tripArr[1];
                                        trip.TripStart = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy") + " " + tripArr[2]);
                                        trip.TripEnd = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy") + " " + tripArr[3]);
                                        trip.DistanceTravelled = Convert.ToDouble(tripArr[4]);
                                        //trip.TripVelocity = trip.DistanceTravelled / (trip.TripEnd.Subtract(trip.TripStart).TotalMinutes / 60.00);
                                        trip.TotalMinutes = (trip.TripEnd.Subtract(trip.TripStart).TotalMinutes);

                                        tripList.Add(trip);
                                    }
                                }
                            }
                        }
                    }

                    if (driverList != null & driverList.Count > 0)
                    {
                        foreach (var drvItem in driverList)
                        {
                            drvItem.TripList = tripList.Where(x => x.DriverName == drvItem.Name).Select(y => y).ToList();
                        }
                        using (BusinessLayer.RootTripBAL obj = new BusinessLayer.RootTripBAL())
                        {
                            driverList = obj.InsertDriverAndTrip(driverList);

                            tripList = obj.SelectDriverTripDetails();
                        }
                    }
                }

                //Send OK Response to Client.
                return Request.CreateResponse(HttpStatusCode.OK, tripList);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, ex.ToString());
            }
        }

        //[Route("api/CodeKataUpload/SelectDriverTripDetails")]
        [HttpGet]
        public HttpResponseMessage SelectDriverTripDetails()
        {
            BusinessLayer.RootTripBAL rootTripBalObj = new BusinessLayer.RootTripBAL();
            List<Trip> tripList = rootTripBalObj.SelectDriverTripDetails();
            return Request.CreateResponse(HttpStatusCode.OK, tripList);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using System.Data;

namespace DataAccessLayer
{
    public class RootTripDAL
    {
        public int InsertDriver(Driver driverDetails)
        {
            object obj = SqlHelper.ExecuteSPReturnScaler(new object[] { "Usp_Driver_Insert",
                                                                        "@Name", driverDetails.Name
                                                                     });
            return Convert.ToInt32(obj);
        }

        public int InsertTrip(Trip tripDetails)
        {
            object obj = SqlHelper.ExecuteSPReturnScaler(new object[] { "Usp_Trip_Insert",
                                                                        "@DriverID", tripDetails.DriverID,
                                                                        "@StartTime", tripDetails.TripStart,
                                                                        "@EndTime", tripDetails.TripEnd,
                                                                        "@DistanceTravelled", tripDetails.DistanceTravelled,
                                                                        "@TotalMinutes", tripDetails.TotalMinutes,
                                                                     });
            return Convert.ToInt32(obj);
        }

        public List<Trip> SelectTripDetails()
        {
            DataTable dt = SqlHelper.ExecuteSPReturnDT(new object[] { "Usp_Select_Driver_Trip" });
            List<Trip> tripListObj = new List<Trip>();
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    tripListObj.Add(new Trip
                    {
                        DriverName = dr["Name"].ToString(),
                        DistanceTravelled = dr["Distance"] != DBNull.Value ? Math.Round(Convert.ToDouble(dr["Distance"])) : (0),
                        TotalMinutes = dr["TotalMinutes"] != DBNull.Value ? Math.Round(Convert.ToDouble(dr["TotalMinutes"])) : (0),
                        TripVelocity = dr["TripVelocity"] != DBNull.Value ? Math.Round(Convert.ToDouble(dr["TripVelocity"])) : (0),
                    });
                }
                return tripListObj;
            }
            else
            {
                return new List<Trip>();
            }
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class Driver
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public DateTime AddedOn { get; set; }
        public int UploadFileID { get; set; }
        public List<Trip> TripList { get; set; }
    }

    public class Trip
    {
        public int DriverID { get; set; }
        public string DriverName { get; set; }
        public double TripVelocity { get; set; }
        public DateTime TripStart { get; set; }
        public DateTime TripEnd { get; set; }
        public double TotalMinutes { get; set; }
        public double DistanceTravelled { get; set; }
    }
}

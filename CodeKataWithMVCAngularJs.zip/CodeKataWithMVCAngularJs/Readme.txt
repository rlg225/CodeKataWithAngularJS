Code Kata-Root Trip
1: Created project in MVC with Angular JS 
2: Added DB scripes(tables and procedures) and saved data into DB when reading data from input file.
3: Displayed all the data in controls as requird.
4: Included entity, DAL, BAL and UI in solution.
5: 

NOTE: Please build solution when project runs first time one by one prject and then please have a look.


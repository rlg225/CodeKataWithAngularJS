
CREATE Procedure Usp_Driver_Insert
     @Name	varchar(250)    
AS
 BEGIN
 Declare @CurrentRowId int

	INSERT INTO Driver
				(
					Name,
					CreatedDate
				)
	values		
				(
				 @Name,
				 GETDATE()
				)

	Select SCOPE_IDENTITY()
 END

 -----------------
 GO

Create Procedure Usp_Trip_Insert
@DriverID int,
@StartTime datetime,
@EndTime datetime,
@DistanceTravelled decimal(18,2),
@TotalMinutes decimal(18,2)
AS
 BEGIN
 Declare @CurrentRowId int

	INSERT INTO Trip
				(
					 DriverID
					,StartTime
					,EndTime
					,DistanceTravelled
					,TotalMinutes
				)
	values		
				(
					 @DriverID
					,@StartTime
					,@EndTime
					,@DistanceTravelled
					,@TotalMinutes
				)

	Select SCOPE_IDENTITY()
 END

 GO
 -------------

 Create procedure Usp_Select_Driver_Trip
 AS
  BEGIN
select 
	Name,
	SUM(DistanceTravelled) as Distance, 
	Sum(TotalMinutes) as TotalMinutes,
	SUM(DistanceTravelled)/(Sum(TotalMinutes)/60.0) as TripVelocity
from Driver
left join Trip on ID = trip.DriverID group BY Name
order by Distance desc
END




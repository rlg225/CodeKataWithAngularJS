﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using DataAccessLayer;

namespace BusinessLayer
{
    public class RootTripBAL : IDisposable
    {
        RootTripDAL rootTripDal = new RootTripDAL();

        public List<Driver> InsertDriverAndTrip(List<Driver> driverList)
        {
            if (driverList != null && driverList.Count > 0)
            {
                foreach (var driverItem in driverList)
                {
                   int driverID =  rootTripDal.InsertDriver(driverItem);
                    if (driverID > 0)
                    {
                        if (driverItem.TripList != null && driverItem.TripList.Count > 0)
                        {
                            foreach (var tripItem in driverItem.TripList)
                            {
                                tripItem.DriverID = driverID;
                                int tripID = rootTripDal.InsertTrip(tripItem);
                            }
                        }
                    }

                }
            }

            return driverList;

        }

        public List<Trip> SelectDriverTripDetails()
        {
            return rootTripDal.SelectTripDetails();
        }

        public void Dispose()
        {
            rootTripDal = null;
        }
    }
}
